import pandas as pd

def cargar_csv(filename):
    # Esta funcion debe leer un archivo csv y retornar un dataframe
    pass

def cargar_tsv(filename):
    # Esta funcion debe leer un archivo tsv y retornar un dataframe
    pass

def cargar_cabecera(df):
    # Esta funcion debe recibir un dataframe y devolver la cabecera del mismo
    pass

def obtener_columnas(df):
    # Esta funcion debe recibir un dataframe y devolver las columnas del dataframe
    pass

def obtener_estadistica_basica(df,columna):
    # Esta funcion debe recibir un dataframe y devolver las estadisticas de una
    # columna 
    pass



def encontrar_peliculas_con_valores_atipicos():
    # Debe leer los archivos necesarios para obtener
    # los valores atipicos en numeros de votos y obtener el nombre
    # de las peliculas que tienes estos valores atipicos
    # esta funcion debe retornar un dataframe que contenga las 
    # peliculas con valores atipicos
    pass


def obtener_cantidad_peliculas_por_genero():
    # Debe generar un dataframe que contenga la cantidad de peliculas
    # para cada genero, la columna de la cantidad de peliculas debe
    # tener el nombre de cantidad, mientras que la columna de genero
    # debe llamarse genero  
    pass
   

 


def obtener_top_5_peliculas_con_mas_bajo_raiting():
    # Debe generar un dataframe que contenga las 5 peliculas
    # con el peor raiting 
    pass
    




